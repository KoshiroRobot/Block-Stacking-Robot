/*
 * i2c_slave.c
 *
 *  Created on: Oct 10, 2024
 *      Author: taise
 */


#include "main.h"
#include "i2c_slave.h"

extern ADC_HandleTypeDef hadc;
extern DMA_HandleTypeDef hdma_adc;
extern I2C_HandleTypeDef hi2c1;

extern TIM_HandleTypeDef htim3;
extern TIM_HandleTypeDef htim14;


extern uint32_t ADCValue;

float adcNow;

//ローパスフィルタ0~1
float alpha = 1;
float last_filtered_ADC = 0;
float filtered_ADC = 0;

float beta = 1;
float last_filtered_Output = 0;
float filtered_Output = 0;

float Kp = 30;
float Ki = 0;
float Kd = 50;
float adcValAtAngleMin=250;
float adcValAtAngleMax=3000;
float mechanicalAngleMin=0;
float mechanicalAngleMax=180;
float MaxOutput = 1000;        //出力0~1000

#define INTEGRAL_LIMIT 500
#define MOTOR_CONTROL_CYCLE 0.005

//変数
float angleNow = 0;
float errorAngle;
float errorAngleLast = 0;
float deltaAngle = 0;
float integralAngle = 0;

float Output = 0;


//i2cで変えるやつら
float motorPower = 0;//後で0に
float angleGoal = 0;

#define RxSize 5
#define TxSize 5
uint8_t RxData[RxSize];
uint8_t TxData[TxSize];


void HAL_I2C_ListenCpltCallback(I2C_HandleTypeDef *hi2c)
{
	HAL_I2C_EnableListen_IT(hi2c);
}


void HAL_I2C_AddrCallback(I2C_HandleTypeDef *hi2c, uint8_t TransferDirection, uint16_t AddrMatchCode)
{
	if(TransferDirection == I2C_DIRECTION_TRANSMIT)
	{
		HAL_I2C_Slave_Sequential_Receive_IT(hi2c, RxData, RxSize, I2C_FIRST_AND_LAST_FRAME);
	}
	else
	{
		HAL_I2C_Slave_Sequential_Transmit_IT(hi2c, TxData, TxSize, I2C_FIRST_AND_LAST_FRAME);
	}
}

void HAL_I2C_SlaveRxCpltCallback(I2C_HandleTypeDef* hi2c)
{
    float Data = *((float*) (RxData + 1));

    switch (RxData[0])
    {
    // 0x0- : サーボの定数の設定
    case 0x01: // モータON
    {
    	motorPower = 1;
    	break;
    }
    case 0x02: // モータOFF
    {
    	motorPower = 0;
    	break;
    }
    case 0x03: // 比例ゲインKpの変更
    {
    	Kp = Data;
    	break;
    }
    case 0x04: // 微分ゲインKdの変更
    {
    	Kd = Data;
    	break;
    }
    case 0x05: // 積分ゲインKiの変更
    {
    	Ki = Data;
    	break;
    }
    case 0x06: // 機械角の最小値mechanicalAngleMinを設定
    {
    	mechanicalAngleMin = Data;
    	break;
    }
    case 0x07: // 機械角の最大値mechanicalAngleMaxを設定
	{
		mechanicalAngleMax = Data;
		break;
	}
    case 0x08: // 機械角の最小値adcValAtAngleMinを設定
	{
		adcValAtAngleMin = Data;
		break;
	}
	case 0x09: // 機械角の最大値adcValAtAngleMaxを設定
	{
		adcValAtAngleMax = Data;
		break;
	}
    case 0x0a: // 最大出力（トルク）MaxOutputを設定
    {
    	MaxOutput = Data;
    	break;
    }
    case 0x0b: //ローパスフィルタの係数alphaを設定
    {
    	alpha = Data;
    	break;
    }
    case 0x0c: //ローパスフィルタの係数betaを設定
	{
		beta = Data;
		break;
	}

    // 0x1- : マスターへの情報準備
    case 0x11: //現在の角度を準備
	{
		TxData[0] = RxData[0];
		unsigned char* backData = (unsigned char*) &(angleNow);
		for (int i = 0; i < 4; i++) {
			TxData[i + 1] = *(backData + i);
		}
		break;
	}
    case 0x12: //現在の速度を準備
    {
    	TxData[0] = RxData[0];
    	float velocityNow = deltaAngle/MOTOR_CONTROL_CYCLE;
    	unsigned char* backData = (unsigned char*) &(velocityNow);
		for (int i = 0; i < 4; i++) {
			TxData[i + 1] = *(backData + i);
		}
		break;
    }
    case 0x13: //現在の出力を準備
    {
    	TxData[0] = RxData[0];
    	unsigned char* backData = (unsigned char*) &(Output);
		for (int i = 0; i < 4; i++) {
			TxData[i + 1] = *(backData + i);
		}
		break;
    }
    case 0x14: //現在の電圧取得値を準備
    {
    	TxData[0] = RxData[0];
    	if (HAL_ADC_Start_DMA(&hadc, (uint32_t*)&ADCValue, 1) != HAL_OK)
			{
				Error_Handler();
			}
    	adcNow = ADCValue;
    	unsigned char* backData = (unsigned char*) &(adcNow);
		for (int i = 0; i < 4; i++) {
			TxData[i + 1] = *(backData + i);
		}
		break;
    }

    // 0x2- : マスターから情報を受け取る
	case 0x20: //目標角度を受け取る
	{
		angleGoal = Data;
		break;
	}
	default:
		break;
    }
}

void CalcOutput(void)
{
	//値を更新する
	errorAngle = angleNow - angleGoal;
	deltaAngle = errorAngle - errorAngleLast;
	errorAngleLast = errorAngle;

	//角度積分の上限を調整
	integralAngle += errorAngle;
	if (integralAngle > INTEGRAL_LIMIT) integralAngle = INTEGRAL_LIMIT;
	else if (integralAngle < -INTEGRAL_LIMIT) integralAngle = -INTEGRAL_LIMIT;


	//角速度積分の上限を調整
	/*errorVelocity = velocityNow - velocityGoal;
	integralVelocity += errorVelocity;
	if (integralVelocity > INTEGRAL_LIMIT) integralVelocity = INTEGRAL_LIMIT;
	else if (integralVelocity < -INTEGRAL_LIMIT) integralVel = -INTEGRAL_LIMIT;*/

	//出力をPIDで計算
	/*Output = Kp * errorAngle +
				 Ki * integralAngle + Kv * integralVelocity +
				 Kd * deltaAngle;*/

	Output = Kp * errorAngle +
					 Ki * integralAngle +
					 Kd * deltaAngle;

	filtered_Output = beta*Output + (1-beta)*last_filtered_Output;
	last_filtered_Output = filtered_Output;


	//出力の上限を調整(-1000~1000)
	if (Output > MaxOutput) Output = MaxOutput;
	else if (Output < -MaxOutput) Output = -MaxOutput;
}

void SetPWM(void)
{
    if (motorPower == 1)
    {
        if (Output >= 0)
        {
            __HAL_TIM_SET_COMPARE(&htim3, TIM_CHANNEL_1, 0);
            __HAL_TIM_SET_COMPARE(&htim3, TIM_CHANNEL_2, Output);
        } else
        {
            __HAL_TIM_SET_COMPARE(&htim3, TIM_CHANNEL_2, 0);
            __HAL_TIM_SET_COMPARE(&htim3, TIM_CHANNEL_1, -Output);
        }
    } else
    {
        __HAL_TIM_SET_COMPARE(&htim3, TIM_CHANNEL_2, 0);
        __HAL_TIM_SET_COMPARE(&htim3, TIM_CHANNEL_1, 0);
    }
}


// Control loop
void HAL_TIM_PeriodElapsedCallback(TIM_HandleTypeDef* htim)
{
    if (htim->Instance == TIM14)
    {
    	//アナログ値を取得
    	if (HAL_ADC_Start_DMA(&hadc, (uint32_t*)&ADCValue, 1) != HAL_OK)
    	    {
    	        Error_Handler();
    	    }
    	filtered_ADC = alpha*ADCValue + (1-alpha)*last_filtered_ADC;
    	last_filtered_ADC = filtered_ADC;

    	angleNow = mechanicalAngleMin +
					  (mechanicalAngleMax - mechanicalAngleMin) *
					  ((float) filtered_ADC - (float) adcValAtAngleMin) /
					  ((float) adcValAtAngleMax - (float) adcValAtAngleMin);

    	CalcOutput();
    	SetPWM();

    	/*t++;
        if (t > 999)
        {
        	t = 0;
        }*/
    }
}
