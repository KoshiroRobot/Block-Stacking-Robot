/*
 * i2c_slave.h
 *
 *  Created on: Oct 10, 2024
 *      Author: taise
 */

#ifndef INC_I2C_SLAVE_H_
#define INC_I2C_SLAVE_H_



#endif /* INC_I2C_SLAVE_H_ */
