/*
 * servo_encoder.c
 *
 *  Created on: Oct 14, 2024
 *      Author: taise
 */


#include "main.h"
#include "servo_encoder.h"


extern I2C_HandleTypeDef hi2c1;
extern TIM_HandleTypeDef htim3;


extern float StepGoal;
extern float StepNow;

extern float status;


#define RxSize 5
#define TxSize 5
uint8_t RxData[RxSize];
uint8_t TxData[TxSize];



void HAL_I2C_ListenCpltCallback(I2C_HandleTypeDef *hi2c)
{
	HAL_I2C_EnableListen_IT(hi2c);
}


void HAL_I2C_AddrCallback(I2C_HandleTypeDef *hi2c, uint8_t TransferDirection, uint16_t AddrMatchCode)
{
	if(TransferDirection == I2C_DIRECTION_TRANSMIT)
	{
		HAL_I2C_Slave_Sequential_Receive_IT(hi2c, RxData, RxSize, I2C_FIRST_AND_LAST_FRAME);
	}
	else
	{
		HAL_I2C_Slave_Sequential_Transmit_IT(hi2c, TxData, TxSize, I2C_FIRST_AND_LAST_FRAME);
	}
}


void HAL_I2C_SlaveRxCpltCallback(I2C_HandleTypeDef* hi2c)
{
    float Data = *((float*) (RxData + 1));

    switch (RxData[0])
    {
    case 0x11: //現在のステップを準備
	{
		TxData[0] = RxData[0];
		unsigned char* backData = (unsigned char*) &(StepNow);
		for (int i = 0; i < 4; i++) {
			TxData[i + 1] = *(backData + i);
		}
		break;
	}

	case 0x20: //目標角度を受け取る
	{
		StepGoal = Data;
		break;
	}
	case 0x21://再起動
	{
		HAL_NVIC_SystemReset();
		break;
	}
	case 0x22: //ステータスを教える
	{
		TxData[0] = RxData[0];
		unsigned char* backData = (unsigned char*) &(status);
		for (int i = 0; i < 4; i++) {
			TxData[i + 1] = *(backData + i);
		}
		break;
	}
	default:
		break;
    }
}
