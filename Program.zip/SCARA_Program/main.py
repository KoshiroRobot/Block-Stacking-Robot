import scara
import time


#変数を定義--------------------------------

goal = [60, 100]
tolerance_length = 5 # mm


#関数を定義--------------------------------

def set_endeffector(goal_coord):
    # 目標位置へエンドエフェクターを移動させる
    movement_time_theta = 1
    movement_time_r = 1
    robot.move_to_Target_Position(goal_coord, movement_time_theta, movement_time_r)
    last_x_goal = goal_coord[0]
    last_y_goal = goal_coord[1]

    # エンドエフェクターの座標をステレオ計測
    endeffector_3d_coord = robot.get_endeffector_position_via_stereo()
    print(f"endeffector:{endeffector_3d_coord}")

    # エンドエフェクターの位置を微調整
    # エンドエフェクターの座標を取得
    endeffector_position = endeffector_3d_coord[0]
    x_endeffector = float(endeffector_position[0])
    y_endeffector = float(endeffector_position[1])

    # 誤差を計算
    x_error = goal_coord[0] - x_endeffector
    y_error = goal_coord[1] - y_endeffector

    # 誤差が許容内になるまで調整し続ける
    while(abs(x_error) > tolerance_length or abs(y_error) > tolerance_length):
        next_goal_x = last_x_goal + x_error
        next_goal_y = last_y_goal + y_error

        movement_time_theta = 0.5
        movement_time_r = 0.5
        robot.move_to_Target_Position([next_goal_x, next_goal_y], movement_time_theta, movement_time_r)
        last_x_goal = next_goal_x
        last_y_goal = next_goal_y
        time.sleep(1)

        endeffector_3d_coord = robot.get_endeffector_position_via_stereo()
        print(f"endeffector:{endeffector_3d_coord}")

        endeffector_position = endeffector_3d_coord[0]
        x_endeffector = float(endeffector_position[0])
        y_endeffector = float(endeffector_position[1])

        x_error = goal_coord[0] - x_endeffector
        y_error = goal_coord[1] - y_endeffector

    print("The end effector is within the allowable tolerance range.")



#メインプログラム----------------------------------

#SCARAロボットをインスタンス化
robot = scara.Scara()


#ポンプをオフにする．
robot.pump_off()

#精度を高めるために，プログラム開始時に毎回キャリブレーション
robot.calibrate_joint()

#初期計測の邪魔にならないように，エンドエフェクターを最小位置に移動する．
x_init, y_init = robot.polar_to_cartesian(robot.radius_min, robot.theta_min)
coord_init = [x_init, y_init]
movement_time_theta = 1
movement_time_r = 1
robot.move_to_Target_Position(coord_init, movement_time_theta, movement_time_r)




#初期計測
block_coords = robot.first_stereo_measurement()

#経路設計
block_order = robot.plan_trajectory(block_coords)
print(f"blue0:{block_order[0]}, red0:{block_order[1]}, blue1:{block_order[2]}, red1:{block_order[3]}")


#一つ目のブロックをゴールへ運ぶ------------------------------------------

#エンドエフェクターの高さを調整
robot.set_endeffector_height(robot.first_height)

#最初のブロックへエンドエフェクターを移動させる
set_endeffector(block_order[0])

#ブロックの高さまでエンドエフェクターを下げる
robot.set_endeffector_height(robot.block_height)

#ポンプをオンにする．
robot.pump_on()
time.sleep(1)

#ブロックを持ち上げる．
robot.set_endeffector_height(robot.second_height)

#ブロックをゴールへ移動させる
set_endeffector(goal)

#ブロックを下す
robot.set_endeffector_height(robot.block_height)

#ポンプをオフにする
robot.pump_off()


#二つ目のブロックをゴールへ運ぶ---------------------------------

#エンドエフェクターの高さを調整
robot.set_endeffector_height(robot.first_height)

#二つ目のブロックへエンドエフェクターを移動させる
set_endeffector(block_order[1])

#ブロックの高さまでエンドエフェクターを下げる
robot.set_endeffector_height(robot.block_height-2)

#ポンプをオンにする．
robot.pump_on()
time.sleep(1)

#ブロックを持ち上げる．
robot.set_endeffector_height(robot.second_height)

#ブロックをゴールへ移動させる
set_endeffector(goal)

#ブロックを下す
robot.set_endeffector_height(robot.block2_height)

#ポンプをオフにする
robot.pump_off()



#3つ目のブロックをゴールへ運ぶ---------------------------------

#エンドエフェクターの高さを調整
robot.set_endeffector_height(robot.second_height)

#3つ目のブロックへエンドエフェクターを移動させる
set_endeffector(block_order[2])

#ブロックの高さまでエンドエフェクターを下げる
robot.set_endeffector_height(robot.block_height-2)

#ポンプをオンにする．
robot.pump_on()
time.sleep(1)

#ブロックを持ち上げる．
robot.set_endeffector_height(robot.third_height)

#ブロックをゴールへ移動させる
set_endeffector(goal)

#ブロックを下す
robot.set_endeffector_height(robot.block3_height)

#ポンプをオフにする
robot.pump_off()


#4つ目のブロックをゴールへ運ぶ---------------------------------

#エンドエフェクターの高さを調整
robot.set_endeffector_height(robot.third_height)

#4つ目のブロックへエンドエフェクターを移動させる
set_endeffector(block_order[3])

#ブロックの高さまでエンドエフェクターを下げる
robot.set_endeffector_height(robot.block_height)

#ポンプをオンにする．
robot.pump_on()
time.sleep(1)

#ブロックを持ち上げる．
robot.set_endeffector_height(robot.forth_height)

#ブロックをゴールへ移動させる
set_endeffector(goal)

#ブロックを下す
robot.set_endeffector_height(robot.block4_height)

#ポンプをオフにする
robot.pump_off()


#エンドエフェクターを初期位置へ移動
movement_time_theta = 1
movement_time_r = 1
robot.move_to_Target_Position(coord_init, movement_time_theta, movement_time_r)



time.sleep(1)
robot.scara_close()