import time
import os
import cv2
from picamera2 import Picamera2
from PIL import Image

# カメラ番号を入力で指定
camera_number = int(input("カメラ番号を入力してください（0 または 1）: "))

# 入力されたカメラ番号が0か1かを確認
if camera_number not in [0, 1]:
    print("無効なカメラ番号です。0 または 1 を入力してください。")
    exit()

# 保存先ディレクトリの作成（存在しない場合）
save_dir = f'./Images_for_Calib_Camera{camera_number}'
if not os.path.exists(save_dir):
    os.makedirs(save_dir)

# カメラの設定
camera = Picamera2(camera_number)
config = camera.create_still_configuration(main={"size": (640, 480)})  # 静止画用設定
camera.configure(config)

# カメラを起動
camera.start()

# 写真のカウント
photo_count = 0

#撮影する枚数
photo_num = 180

# 30枚の写真を保存し、リアルタイムで映像を表示
while photo_count < photo_num:
    # カメラからフレームを取得
    frame = camera.capture_array()

    # 画像をBGR形式に変換してから表示
    frame_bgr = cv2.cvtColor(frame, cv2.COLOR_RGB2BGR)
    cv2.imshow("Camera", frame_bgr)

    # 'q'キーで終了可能に
    key = cv2.waitKey(1) & 0xFF
    if key == ord('q'):
        camera.stop()
        cv2.destroyAllWindows()
        exit()

    # Enterキーが押されたら、現在のフレームを保存 (Enterキーのコードは13)
    if key == 13:
        photo_count += 1
        # PILを使用して画像を保存
        file_name = f"{save_dir}/image_{photo_count}.jpg"
        Image.fromarray(frame).save(file_name)
        print(f"写真 {file_name} を保存しました。{photo_count}/{photo_num}")

# カメラリソースを解放
camera.stop()
cv2.destroyAllWindows()
print("写真撮影完了。")
