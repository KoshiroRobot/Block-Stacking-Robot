import matplotlib
matplotlib.use('TkAgg')

from picamera2 import Picamera2
from PIL import Image
import matplotlib.pyplot as plt

import numpy as np
import cv2
import os

# カメラ番号の入力
camera_num = int(input("カメラ番号を入力してください (0または1): "))

# カメラ行列と歪み係数をファイルから読み取る
camera_matrix_file = f'camera_matrix{camera_num}.npy'
dist_coeffs_file = f'dist_coeffs{camera_num}.npy'

# ファイルが存在するか確認
if not os.path.exists(camera_matrix_file) or not os.path.exists(dist_coeffs_file):
    print(f"{camera_matrix_file} または {dist_coeffs_file} が見つかりませんでした。")
    exit()

# カメラ行列と歪み係数を読み込み
selected_camera_matrix = np.load(camera_matrix_file)
selected_dist_coeffs = np.load(dist_coeffs_file)

h, w = 480, 640  # 画像の高さと幅

# picamera2を使って画像を取得する
camera = Picamera2(camera_num)
config = camera.create_preview_configuration(main={"size": (w, h)})
camera.configure(config)
camera.start()

# 画像を取得
image = camera.capture_array()
camera.stop()

# 画像の色空間をRGBに変換
image = cv2.cvtColor(image, cv2.COLOR_RGB2BGR)

# 画像をPillow形式に変換
image = Image.fromarray(image)

# クリックされた座標を保存するリスト
clicked_points = []

# クリックイベントの処理関数
def onclick(event):
    x, y = event.xdata, event.ydata
    if x is not None and y is not None:
        clicked_points.append([int(x), int(y)])
        print(f'クリックされた座標: ({int(x)}, {int(y)})')

# エンターキーが押されたときの処理
def on_key(event):
    if event.key == 'enter':
        print("最終的な座標リスト:")
        formatted_points = ",".join([f"[{p[0]}, {p[1]}]" for p in clicked_points])
        print(formatted_points)

        if len(clicked_points) == 24:
            # PnP問題を解く
            object_points = np.array([
                [56.3, -67.6, 0], [76.2, -91.4, 0],
                [49.0, -28.3, 0], [76.2, -44.0, 0], [103.1, -59.5, 0], [129.6, -74.8, 0],
                [56.6, 0, 0], [88.0, 0, 0], [119.0, 0, 0], [149.6, 0, 0],
                [49.0, 28.3, 0], [76.2, 44.0, 0], [103.1, 59.5, 0], [129.6, 74.8, 0],
                [28.3, 49.0, 0], [44.0, 76.2, 0], [59.5, 103.1, 0], [74.8, 129.6, 0],
                [0, 56.6, 0], [0, 88.0, 0], [0, 119.0, 0], [0, 149.0, 0],
                [-20.2, 85.6, 0], [-27.4, 115.8, 0]
            ], dtype=np.float32)

            image_points = np.array(clicked_points, dtype=np.float32)

            # PnPを解く
            success, rotation_vector, translation_vector = cv2.solvePnP(
                object_points,
                image_points,
                selected_camera_matrix,
                selected_dist_coeffs
            )

            if success:
                print(f'Rotation Vector:\n{rotation_vector}')
                print(f'Translation Vector:\n{translation_vector}')

                # オブジェクトポイントを画像上に再投影
                projected_points, _ = cv2.projectPoints(
                    object_points,
                    rotation_vector,
                    translation_vector,
                    selected_camera_matrix,
                    selected_dist_coeffs
                )

                projected_points = projected_points.reshape(-1, 2)
                errors = np.linalg.norm(image_points - projected_points, axis=1)
                mean_error = np.mean(errors)
                print(f'平均再投影誤差: {mean_error} ピクセル')

                # rotation_vectorとtranslation_vectorを保存
                np.save(f'rotation_vector{camera_num}.npy', rotation_vector)
                np.save(f'translation_vector{camera_num}.npy', translation_vector)
                print(f'rotation_vector{camera_num}.npy と translation_vector{camera_num}.npy を保存しました。')

            else:
                print("PnP問題の解決に失敗しました")

        else:
            print("24個の点をクリックしてください。")

        plt.close()  # 画像を閉じる

# 画像をプロット
fig, ax = plt.subplots()
ax.imshow(image)

# クリックイベントを接続
cid_click = fig.canvas.mpl_connect('button_press_event', onclick)

# キーボードイベントを接続
cid_key = fig.canvas.mpl_connect('key_press_event', on_key)

plt.show()
