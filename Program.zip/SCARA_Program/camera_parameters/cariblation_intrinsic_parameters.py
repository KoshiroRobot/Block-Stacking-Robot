import cv2
import numpy as np
import os

# カメラ番号を入力で指定
camera_number = int(input("カメラ番号を入力してください（0 または 1）: "))

# 入力されたカメラ番号が0か1かを確認
if camera_number not in [0, 1]:
    print("無効なカメラ番号です。0 または 1 を入力してください。")
    exit()

# キャリブレーション用画像のリスト
images = [f'./Images_for_Calib_Camera{camera_number}/image_{i}.jpg' for i in range(1, 181)]  # 1から180までの画像を使用


# チェッカーボードのサイズ (内部の角の数)
chessboard_size = (7, 7)

# 3Dポイントの準備 (各正方形のサイズは25.4mm)
square_size = 25.4  # mm
objp = np.zeros((chessboard_size[0] * chessboard_size[1], 3), np.float32)
objp[:, :2] = np.mgrid[0:chessboard_size[0], 0:chessboard_size[1]].T.reshape(-1, 2) * square_size

# 3Dポイントと2Dポイントのリスト
objpoints = []
imgpoints = []

for fname in images:
    if not os.path.exists(fname):
        print(f"ファイルが見つかりません: {fname}")
        continue

    img = cv2.imread(fname)
    if img is None:
        print(f"画像の読み込みに失敗しました: {fname}")
        continue

    # 画像の表示（デバッグ用）
    cv2.imshow('Original Image', img)
    cv2.waitKey(500)

    gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
    
    # グレースケール画像の表示（デバッグ用）
    cv2.imshow('Grayscale Image', gray)
    cv2.waitKey(500)

    ret, corners = cv2.findChessboardCorners(gray, chessboard_size, None)
    
    # 角が見つかったかどうかのデバッグメッセージ
    if ret:
        print(f"チェッカーボードの角が見つかりました: {fname}")
        objpoints.append(objp.copy())  # Add a copy of objp to avoid modifications
        imgpoints.append(corners)

        # 角の描画
        cv2.drawChessboardCorners(img, chessboard_size, corners, ret)
        cv2.imshow('Detected Corners', img)
        cv2.waitKey(500)
    else:
        print(f"チェッカーボードの角が見つかりませんでした: {fname}")

cv2.destroyAllWindows()

if len(objpoints) > 0 and len(imgpoints) > 0:
    # カメラキャリブレーション
    ret, camera_matrix, dist_coeffs, rvecs, tvecs = cv2.calibrateCamera(objpoints, imgpoints, gray.shape[::-1], None, None)

    # 結果の表示
    print("Camera matrix:\n", camera_matrix)
    print("Distortion coefficients:\n", dist_coeffs)

    # キャリブレーション結果の保存
    np.save(f'camera_matrix{camera_number}.npy', camera_matrix)
    np.save(f'dist_coeffs{camera_number}.npy', dist_coeffs)
else:
    print("キャリブレーションに使用できる有効な画像がありませんでした。")
