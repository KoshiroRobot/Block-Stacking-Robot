import servo
import camera
import time
import math
import numpy as np
import itertools
import cv2
import sys
import select

class Scara:
    def __init__(self):

        print("Initializing the robot...")

        #各サーボのPDIゲイン(L1, L2, PP)
        """self.KPs = [10, 10, 400]
        self.KIs = [1.15, 0.7, 0]
        self.KDs = [90, 80, 1000]"""

        self.max_height = 52 #mm
        self.clicks_per_revolution = 24
        self.height_per_revolution = 4 #mm
        self.height_offset = 8 #mm
        self.first_height = 17 + self.height_offset #mm
        self.second_height = 25 + self.height_offset #mm
        self.third_height = 35 + self.height_offset #mm
        self.forth_height = 40 + self.height_offset #mm
        
        self.block_height =  7+ self.height_offset #mm
        self.block2_height = 18 + self.height_offset #mm
        self.block3_height = 28 + self.height_offset #mm
        self.block4_height = 38 + self.height_offset #mm


        self.KPs = [60, 60, 80]
        self.KIs = [0.4, 0.4, 0]
        self.KDs = [500, 500, 500]
        
        #L1: 138 deg, L2: 138 deg
        self.L1_max_angle = 138
        self.L2_max_angle = 138
        self.PP_max_angle = 90

        #各サーボのオフセット(L1, L2, PP)
        self.adcMAXs = [3039.0, 2720.0, 2775]
        self.adcMINs = [213.0, 415.0, 112]
        self.angleMAXs = [self.L1_max_angle, self.L2_max_angle, self.PP_max_angle]
        self.angleMINs = [-self.L1_max_angle, -self.L2_max_angle, -self.PP_max_angle]

        #各サーボの最大出力(0~999)(L1, L2, PP)
        self.OUTPUTs = [999, 999, 750]

        #各サーボのセンサのローパスフィルタの係数(0~1)(L1, L2, PP)
        self.alphas = [0.3, 0.3, 1]

        #各サーボの出力のローパスフィルタの係数(0~1)(L1, L2, PP)
        self.betas = [0.3, 0.3, 1]

        #サーボをインスタンス化
        self.S_L1 = servo.ServoP(0x10)
        self.S_L2 = servo.ServoP(0x20)
        self.S_EE = servo.ServoE(0x30)
        self.S_PP = servo.ServoP(0x40)

        #カメラをインスタンス化
        self.camera0 = camera.Camera(0)
        self.camera1 = camera.Camera(1)

        #各サーボを調整
        self.S_L1.set_PID(self.KPs[0], self.KIs[0], self.KDs[0])
        self.S_L2.set_PID(self.KPs[1], self.KIs[1], self.KDs[1])
        self.S_PP.set_PID(self.KPs[2], self.KIs[2], self.KDs[2])

        #各サーボをキャリブレーション
        self.S_L1.CalibrateADCMotorAngle(self.angleMINs[0], self.angleMAXs[0], self.adcMINs[0], self.adcMAXs[0])
        self.S_L2.CalibrateADCMotorAngle(self.angleMINs[1], self.angleMAXs[1], self.adcMINs[1], self.adcMAXs[1])
        #self.S_EE.zero_cariblation()
        self.S_PP.CalibrateADCMotorAngle(self.angleMINs[2], self.angleMAXs[2], self.adcMINs[2], self.adcMAXs[2])

        #各サーボの最大出力を設定
        self.S_L1.set_MaxOutput(self.OUTPUTs[0])
        self.S_L2.set_MaxOutput(self.OUTPUTs[1])
        self.S_PP.set_MaxOutput(self.OUTPUTs[2])

        #各サーボのセンサー取得値に対するローパスフィルタの係数を設定
        self.S_L1.set_lowpass_filter_alpha(self.alphas[0])
        self.S_L2.set_lowpass_filter_alpha(self.alphas[1])
        self.S_PP.set_lowpass_filter_alpha(self.alphas[2])

        #各サーボのセンサー取得値に対するローパスフィルタの係数を設定
        self.S_L1.set_lowpass_filter_beta(self.betas[0])
        self.S_L2.set_lowpass_filter_beta(self.betas[1])
        self.S_PP.set_lowpass_filter_beta(self.betas[2])

        #各サーボの初期角度を設定
        self.S_L1.set_Init()
        self.S_L2.set_Init()
        self.S_PP.set_Init()

        #各サーボのモータを起動
        self.S_L1.motor_on()
        self.S_L2.motor_on()
        self.S_PP.motor_on()


        #サーボへ命令を出す周期
        self.commandCycle = 0.01 #s
        #速度台形則の加速区間の割合
        self.accelerationTimeRatio = 0.2

        self.safetyFactor = 0.7
        #SG92Rの最大角速度0.1sec/60deg.
        self.vel_max_sg92r = 600*self.safetyFactor
        #L1のSG92Rに対する減速比
        self.decelDurationRatio = 16/48#タイミングプーリーによって決まる
        #L1の最大角速度
        self.vel_max_L1 = self.vel_max_sg92r*self.decelDurationRatio

        #ロボットの幾何学情報
        self.L1 = 65 #mm
        self.L2 = 84.6 #mm

        #作業範囲の幾何学情報
        self.theta_min = -30 #deg.
        self.theta_max = 90 #deg.
        self.radius_min = 56 #mm
        self.radius_max = 150 #mm
        
        

        """
        #サーボEEのキャリブレーションの終了を待つ
        status = self.S_EE.check_status()
        while(status == 0):
            time.sleep(1)
            status = self.S_EE.check_status()"""
        
        print("Robot initialization complete.")
    
    #逆運動学を解く
    def Inverse_Kinematics_2LinkModel(self, x, y):
        c2 = (x**2 + y**2 - self.L1**2 - self.L2**2) / (2 * self.L1 * self.L2)
        c2 = max(min(c2, 1), -1)  # c2を[-1, 1]の範囲に制限
        s2 = math.sqrt(1 - c2**2)
        theta2_radians = math.atan2(s2, c2)
        theta2_degrees = math.degrees(theta2_radians)

        k1 = self.L1 + self.L2 * c2
        k2 = self.L2 * s2
        theta1_radians = math.atan2(y, x) - math.atan2(k2, k1)
        theta1_degrees = math.degrees(theta1_radians)

        THETAs = [theta1_degrees, theta2_degrees]
        return THETAs

    def cartesian_to_polar(self, x, y):
        r = math.sqrt(x**2 + y**2)
        theta = math.atan2(y, x)
        return r, theta

    
    def polar_to_cartesian(self, r, theta_degree):
        theta_radians = math.radians(theta_degree)
        x = r * math.cos(theta_radians)
        y = r * math.sin(theta_radians)
        return x, y

    #指定された始点，終点座標が作業範囲内かを判定する,極座標系に変換
    def checkInBounds(self, start_coord, end_coord):
        #極座標に変換
        start_r, start_theta_radians = self.cartesian_to_polar(start_coord[0], start_coord[1])
        start_theta_degrees = math.degrees(start_theta_radians)

        end_r, end_theta_radians = self.cartesian_to_polar(end_coord[0], end_coord[1])
        end_theta_degrees = math.degrees(end_theta_radians)

        if ((self.radius_min <= end_r <= self.radius_max) and (self.theta_min <= end_theta_degrees <= self.theta_max)):
            start_polar_coord = [start_r, start_theta_degrees]
            end_polar_coord  = [end_r, end_theta_degrees]
            POLAR_COORDs = [start_polar_coord, end_polar_coord]
        else:
            POLAR_COORDs = [[None, None], [None, None]]

        return POLAR_COORDs

    #速度台形則に基づ得くパラメータ設計
    def calc_s_LSPB(self, movement_time):
        time_steps = [i * self.commandCycle for i in range(int(movement_time / self.commandCycle) + 1)]
        parameter_s_steps = []

        tb = movement_time*self.accelerationTimeRatio
        VM = 1/(movement_time - tb)
        a = VM/tb

        #区間に応じて
        for t in time_steps:

            if 0 <= t < tb:
                s = (a*(t**2))/2
                parameter_s_steps.append(s)

            elif tb <= t < movement_time - tb:
                s = VM*(t - (tb/2))
                parameter_s_steps.append(s)

            elif movement_time - tb <= t <= movement_time:
                s = 1 - (a*((movement_time - t)**2))/2
                parameter_s_steps.append(s)

        return parameter_s_steps

    #普通の軌道設計
    def calc_s_normal(self, movement_time):
        time_steps = [i * self.commandCycle for i in range(int(movement_time / self.commandCycle) + 1)]
        parameter_s_steps = []
        for t in time_steps:
            s = t/movement_time
            parameter_s_steps.append(s)

        return parameter_s_steps

    #回転角の軌道を決定する関数（極座標的な設計）
    def createJointTrajectory(self, polar_coords, movement_time_theta, movement_time_r, LSPB_ON):
        angle_steps = []

        start_theta_deg = polar_coords[0][1]
        end_theta_deg = polar_coords[1][1]
        start_r = polar_coords[0][0]
        end_r = polar_coords[1][0]

        #速度台形則による極座標のθ方向の移動
        if(LSPB_ON == 1):
            parameter_s_steps_theta = self.calc_s_LSPB(movement_time_theta)
            for s in parameter_s_steps_theta:
                theta_deg = start_theta_deg*(1 - s) + end_theta_deg*s
                x = start_r*math.cos(math.radians(theta_deg))
                y = start_r*math.sin(math.radians(theta_deg))
                THETAs = self.Inverse_Kinematics_2LinkModel(x, y)
                angle_steps.append(THETAs)

            #速度台形則による極座標r方向の移動
            x_waypoint = start_r*math.cos(math.radians(end_theta_deg))
            y_waypoint = start_r*math.sin(math.radians(end_theta_deg))
            x_end = end_r*math.cos(math.radians(end_theta_deg))
            y_end = end_r*math.sin(math.radians(end_theta_deg))
            parameter_s_steps_r = self.calc_s_LSPB(movement_time_r)
            for s in parameter_s_steps_r:
                x = x_waypoint*(1 - s) + x_end*s
                y = y_waypoint*(1 - s) + y_end*s
                THETAs = self.Inverse_Kinematics_2LinkModel(x, y)
                angle_steps.append(THETAs)

        #普通の移動
        else:
            parameter_s_steps_theta = self.calc_s_normal(movement_time_theta)
            for s in parameter_s_steps_theta:
                theta_deg = start_theta_deg*(1 - s) + end_theta_deg*s
                x = start_r*math.cos(math.radians(theta_deg))
                y = start_r*math.sin(math.radians(theta_deg))
                THETAs = self.Inverse_Kinematics_2LinkModel(x, y)
                angle_steps.append(THETAs)

            x_waypoint = start_r*math.cos(math.radians(end_theta_deg))
            y_waypoint = start_r*math.sin(math.radians(end_theta_deg))
            x_end = end_r*math.cos(math.radians(end_theta_deg))
            y_end = end_r*math.sin(math.radians(end_theta_deg))
            parameter_s_steps_r = self.calc_s_normal(movement_time_r)
            for s in parameter_s_steps_r:
                x = x_waypoint*(1 - s) + x_end*s
                y = y_waypoint*(1 - s) + y_end*s
                THETAs = self.Inverse_Kinematics_2LinkModel(x, y)
                angle_steps.append(THETAs)
        
        return angle_steps

    #回転角の軌道に沿ってロボットを動かす
    def move_2Link(self, angle_steps):
        for angles in angle_steps:
            self.S_L1.set_GoalAngle(angles[0])
            self.S_L2.set_GoalAngle(angles[1])
            time.sleep(self.commandCycle)

    #現在の先端座標を取得する
    def get_current_endeffector_position(self):
        S_L1_deg = self.S_L1.get_Angle()
        S_L2_deg = self.S_L2.get_Angle()
        #S_EE_deg = self.S_EE.get_Angle()
        #S_PP_deg = self.S_PP.get_Angle()

        x = (self.L1)*math.cos(math.radians(S_L1_deg)) + (self.L2)*math.cos(math.radians(S_L1_deg + S_L2_deg))
        y = (self.L1)*math.sin(math.radians(S_L1_deg)) + (self.L2)*math.sin(math.radians(S_L1_deg + S_L2_deg))
        coord = []
        coord.append(x)
        coord.append(y)
        return coord

    #目標位置を指定すると，そこへ先端を移動させる
    def move_to_Target_Position(self, goal_coord, movement_time_theta, movement_time_r):
        now_coord = self.get_current_endeffector_position()
        POLAR_COORDs = self.checkInBounds(now_coord, goal_coord)
        if (POLAR_COORDs[0][0] == None):
            print("Target position is outside the workspace.")
            return
        else:
            angle_steps = self.createJointTrajectory(POLAR_COORDs, movement_time_theta, movement_time_r, 1)
            self.move_2Link(angle_steps)

    def project_3D_line_to_image(self, camera_matrix, dist_coeffs, rotation_vector, translation_vector, lines_world, image):
        # カメラの外部パラメータ
        rvec = rotation_vector
        tvec = translation_vector

        # 回転ベクトルを回転行列に変換
        R1, _ = cv2.Rodrigues(rvec)

        # 投影された2Dラインの方程式を格納するリスト
        line_equations = []
        for line in lines_world:
            P0_world = line[0]                # ワールド座標系でのラインの始点
            direction_world = line[1]         # ラインの方向ベクトル

            # direction_worldが正規化されているか確認
            norm_direction = np.linalg.norm(direction_world)
            if norm_direction == 0:
                print("Zero direction vector encountered, skipping this line.")
                continue
            direction_world = direction_world / norm_direction

            # ライン上の2つの3Dポイントを取得
            t1 = 0    # 始点のパラメータ
            t2 = 100  # 終点のパラメータ; 適切な値に設定
            point3D_1 = P0_world + t1 * direction_world
            point3D_2 = P0_world + t2 * direction_world

            # 3Dポイントの配列を作成
            points_3D = np.array([point3D_1.flatten(), point3D_2.flatten()], dtype=np.float32)

            # 3Dポイントを画像平面に投影（歪みなし）
            points_2D, _ = cv2.projectPoints(points_3D, rvec, tvec, camera_matrix, dist_coeffs)

            # points_2D の形状を (N, 2) に変形
            points_2D = points_2D.reshape(-1, 2)

            # 投影された2Dポイントを抽出
            x1, y1 = points_2D[0]
            x2, y2 = points_2D[1]

            # デバッグ用出力
            print(f"x1: {x1}, y1: {y1}")
            print(f"x2: {x2}, y2: {y2}")
            print(f"Types - x1: {type(x1)}, y1: {type(y1)}, x2: {type(x2)}, y2: {type(y2)}")

            # 座標が有限の数値であることを確認
            if not all(map(np.isfinite, [x1, y1, x2, y2])):
                print("Non-finite coordinate encountered, skipping this line.")
                continue

            # ラインの方程式を計算
            a = y2 - y1
            b = x1 - x2
            c = x2 * y1 - x1 * y2

            # 方程式の正規化
            norm = np.sqrt(a**2 + b**2)
            if norm == 0:
                print("Zero norm encountered in line equation, skipping normalization.")
                continue
            a /= norm
            b /= norm
            c /= norm

            line_equations.append((a, b, c))

            # 座標が画像内にある場合のみラインを描画
            height, width = image.shape[:2]
            if 0 <= x1 < width and 0 <= y1 < height and 0 <= x2 < width and 0 <= y2 < height:
                cv2.line(image, (int(x1), int(y1)), (int(x2), int(y2)), (0, 255, 0), 2)
            else:
                print("Line coordinates are out of image bounds, skipping drawing.")

        return line_equations, image




    def match_lines_and_points(self, line_equations, coords):
        n = len(coords)
        distance_matrix = np.zeros((n, n))

        # 距離行列を計算
        for i in range(n):
            x0, y0 = coords[i]
            for j in range(n):
                a, b, c = line_equations[j]
                distance = abs(a * x0 + b * y0 + c)  # 正規化されているので分母は1
                distance_matrix[i, j] = distance

        # すべての可能な組み合わせを評価（nが小さいため可能）
        min_total_distance = None
        best_matching = None
        for perm in itertools.permutations(range(n)):
            total_distance = sum(distance_matrix[i, perm[i]] for i in range(n))
            if min_total_distance is None or total_distance < min_total_distance:
                min_total_distance = total_distance
                best_matching = perm

        # 最適なマッチング結果を返す
        return best_matching

    def compute_3D_position(self, camera0_line, camera1_line):
        P0 = camera0_line[0]  # カメラ0の位置
        d0 = camera0_line[1]   # カメラ0のレイの方向ベクトル（単位ベクトル）
        P1 = camera1_line[0]  # カメラ1の位置
        d1 = camera1_line[1]   # カメラ1のレイの方向ベクトル（単位ベクトル）
        # レイが平行でないことを確認
        cross_d0_d1 = np.cross(d0, d1)
        denom = np.linalg.norm(cross_d0_d1)**2
        
        if denom != 0:
            # 2つのレイ間の最短距離の線分を計算
            w0 = P0 - P1
            a = np.dot(d0, d0)  # a = 1（単位ベクトルなので）
            b = np.dot(d0, d1)
            c = np.dot(d1, d1)  # c = 1（単位ベクトルなので）
            d = np.dot(d0, w0)
            e = np.dot(d1, w0)
            
            s0 = (b * e - c * d) / denom
            s1 = (a * e - b * d) / denom
            
            # 各レイ上の最近接点を計算
            closest_point_on_ray0 = P0 + s0 * d0
            closest_point_on_ray1 = P1 + s1 * d1
            
            # 最近接点間の距離を計算（デバッグや評価のため）
            distance = np.linalg.norm(closest_point_on_ray0 - closest_point_on_ray1)
            
            # 最近接点の中点を物体の位置とする
            object_position = (closest_point_on_ray0 + closest_point_on_ray1) / 2.0
            return [object_position, distance]
        else:
            print("レイが平行のため、位置を特定できません。")
    
    #ブロックの座標を取得する     
    def first_stereo_measurement(self):
        # 各カメラで画像を取得
        image0 = self.camera0.take_pic()
        image1 = self.camera1.take_pic()
        
        # ブロックを検出し、その画像上の座標を取得
        coords0, image0 = self.camera0.find_blocks(image0)
        coords1, image1 = self.camera1.find_blocks(image1)
        
        #両方の画角で4つのブロックの座標が取得できているなら,3D直線を取得
        if (coords0[0][0] != -1 and coords0[1][0] != -1 and coords0[2][0] != -1 and coords0[3][0] != -1 and coords1[0][0] != -1 and coords1[1][0] != -1  and coords1[2][0] != -1 and coords1[3][0] != -1):
            lines_world0 = self.camera0.get_all_lines(coords0)
            lines_world1 = self.camera1.get_all_lines(coords1)
        
            lines0_equations_on_image1, image1 = self.project_3D_line_to_image(self.camera1.camera_matrix, self.camera1.dist_coeffs, self.camera1.rotation_vector, self.camera1.translation_vector, lines_world0, image1)

            # 赤色のブロックについてマッチング
            red_line_equations = lines0_equations_on_image1[:2]
            red_coords = coords1[:2]
            red_matching = self.match_lines_and_points(red_line_equations, red_coords)

            # 青色のブロックについてマッチング
            blue_line_equations = lines0_equations_on_image1[2:]  # 青色の直線（後半の2本）
            blue_coords = coords1[2:]  # 青色のブロックの座標（後半の2つ）
            blue_matching = self.match_lines_and_points(blue_line_equations, blue_coords)

            #対応する直線
            red0_camera0_line = lines_world0[red_matching[0]]
            red0_camera1_line = lines_world1[0]

            red1_camera0_line = lines_world0[red_matching[1]]
            red1_camera1_line = lines_world1[1]

            blue0_camera0_line = lines_world0[blue_matching[0]+2]
            blue0_camera1_line = lines_world1[2]

            blue1_camera0_line = lines_world0[blue_matching[1]+2]
            blue1_camera1_line = lines_world1[3]

            #対応する直線から座標を計算
            red0_3d_coord = self.compute_3D_position(red0_camera0_line, red0_camera1_line)
            red1_3d_coord = self.compute_3D_position(red1_camera0_line, red1_camera1_line)
            blue0_3d_coord = self.compute_3D_position(blue0_camera0_line, blue0_camera1_line)
            blue1_3d_coord = self.compute_3D_position(blue1_camera0_line, blue1_camera1_line)

            return [red0_3d_coord, red1_3d_coord, blue0_3d_coord, blue1_3d_coord]
                         
    #ステージに合わせて関節をキャリブレーションする
    def calibrate_joint(self):
        self.S_L1.motor_off()
        self.S_L2.motor_off()
        while True:
            ADC_L1_MAX = self.S_L1.get_ADC()
            time.sleep(0.2)
            ADC_L2_MIN = self.S_L2.get_ADC()
            print("Move the joints to their minimum positions and press Enter.")
            print(f"MAX_L1:{ADC_L1_MAX}, MIN_L2:{ADC_L2_MIN}")
            time.sleep(0.2)

            # 標準入力にデータがあるか確認
            if sys.stdin in select.select([sys.stdin], [], [], 0)[0]:
                line = sys.stdin.readline()
                if line.strip() == '':
                    print("Enter pressed")
                    break
        
        while True:
            ADC_L1_MIN = self.S_L1.get_ADC()
            time.sleep(0.2)
            ADC_L2_MAX = self.S_L2.get_ADC()
            print("Move the joints to their maximum positions and press Enter.")
            print(f"MIN_L1:{ADC_L1_MIN}, MAX_L2:{ADC_L2_MAX}")
            time.sleep(0.2)

            # 標準入力にデータがあるか確認
            if sys.stdin in select.select([sys.stdin], [], [], 0)[0]:
                line = sys.stdin.readline()
                if line.strip() == '':
                    print("Enter pressed")
                    break

        x_carib_min = self.radius_min*math.cos(math.radians(self.theta_min))
        y_carib_min = self.radius_min*math.sin(math.radians(self.theta_min))
        x_carib_max = self.radius_max*math.cos(math.radians(self.theta_max))
        y_carib_max = self.radius_max*math.sin(math.radians(self.theta_max))
        thetas_min = self.Inverse_Kinematics_2LinkModel(x_carib_min, y_carib_min)
        thetas_max = self.Inverse_Kinematics_2LinkModel(x_carib_max, y_carib_max)

        self.S_L1.CalibrateADCMotorAngle(thetas_min[0], thetas_max[0], ADC_L1_MIN, ADC_L1_MAX)
        time.sleep(0.2)
        self.S_L2.CalibrateADCMotorAngle(thetas_max[1], thetas_min[1], ADC_L2_MIN, ADC_L2_MAX)
        time.sleep(0.2)

        print("The joint calibration is complete.")
        self.S_L1.motor_on()
        self.S_L2.motor_on()

    #ブロックの順番を整える．
    def plan_trajectory(self, block_coords):
        # x と y 座標をfloatとして抽出
        red0_x = float(block_coords[0][0][0])
        red0_y = float(block_coords[0][0][1])
        red0_r, red0_theta_radians = self.cartesian_to_polar(red0_x, red0_y)

        red1_x = float(block_coords[1][0][0])
        red1_y = float(block_coords[1][0][1])
        red1_r, red1_theta_radians = self.cartesian_to_polar(red1_x, red1_y)

        blue0_x = float(block_coords[2][0][0])
        blue0_y = float(block_coords[2][0][1])
        blue0_r, blue0_theta_radians = self.cartesian_to_polar(blue0_x, blue0_y)

        blue1_x = float(block_coords[3][0][0])
        blue1_y = float(block_coords[3][0][1])
        blue1_r, blue1_theta_radians = self.cartesian_to_polar(blue1_x, blue1_y)

        # これ以降のコードを続けて実行
        # 角度を持つブロックリストの作成
        reds = [
            {'coord': block_coords[0][0], 'theta': red0_theta_radians},
            {'coord': block_coords[1][0], 'theta': red1_theta_radians}
        ]

        blues = [
            {'coord': block_coords[2][0], 'theta': blue0_theta_radians},
            {'coord': block_coords[3][0], 'theta': blue1_theta_radians}
        ]

        # ソートとプランニング
        reds_sorted = sorted(reds, key=lambda x: x['theta'], reverse=True)
        blues_sorted = sorted(blues, key=lambda x: x['theta'], reverse=True)

        block_order = [
            blues_sorted[0]['coord'],  # 大きな角度の青ブロック
            reds_sorted[0]['coord'],   # 大きな角度の赤ブロック
            blues_sorted[1]['coord'],  # 残りの青ブロック
            reds_sorted[1]['coord']    # 残りの赤ブロック
        ]
        return block_order


    #エンドエフェクターの座標をステレオ計測
    def get_endeffector_position_via_stereo(self):
        image0 = self.camera0.take_pic()
        image1 = self.camera1.take_pic()

        coord0 = self.camera0.find_endeffector(image0)
        coord1 = self.camera1.find_endeffector(image1)

        camera_position0, ray_world_unit0 = self.camera0.get_straight_line(coord0)
        camera_position1, ray_world_unit1 = self.camera1.get_straight_line(coord1)

        endeffector_3d_coord = self.compute_3D_position([camera_position0, ray_world_unit0], [camera_position1, ray_world_unit1])

        return endeffector_3d_coord

    #エンドエフェクターの高さを調整
    def set_endeffector_height(self, goal_z):
        goal_step = int(((self.max_height - goal_z)/self.height_per_revolution)*self.clicks_per_revolution)
        self.S_EE.set_GoalStep(goal_step)
        time.sleep(1)
        now_step = self.S_EE.get_Step()
        while((now_step > goal_step + 2) or (now_step < goal_step - 2)):
            time.sleep(1)
            now_step = self.S_EE.get_Step()

    def pump_on(self):
        self.S_PP.set_GoalAngle(-90)

    def pump_off(self):
        self.S_PP.set_GoalAngle(90)





    def scara_close(self):
        self.S_L1.close_servo()
        self.S_L2.close_servo()
        self.S_EE.close_servo()
        self.S_PP.close_servo()
        self.camera0.clean_up_cam()
        self.camera1.clean_up_cam()







