import cv2
from picamera2 import Picamera2
import time

h = 480
w = 640

def show_camera_stream(camera0, camera1):
    prev_time = time.time()
    fps = 0

    while True:
        # カメラ0から画像を取得
        image0 = camera0.capture_array()
        image0 = cv2.cvtColor(image0, cv2.COLOR_RGB2BGR)
        image0 = cv2.flip(image0, -1)

        # カメラ0の画像を表示
        cv2.imshow("Camera 0", image0)

        # カメラ1から画像を取得
        image1 = camera1.capture_array()
        image1 = cv2.cvtColor(image1, cv2.COLOR_RGB2BGR)
        image1 = cv2.flip(image1, -1)

        # FPSの計算
        curr_time = time.time()
        fps = 1 / (curr_time - prev_time)
        prev_time = curr_time

        # FPSをimage1に表示（左上）
        cv2.putText(image1, f"FPS: {fps:.2f}", (10, 30), cv2.FONT_HERSHEY_SIMPLEX, 1, (255, 0, 0), 2, cv2.LINE_AA)
        cv2.imshow("Camera 1", image1)

        # 'q' キーを押すと終了
        if cv2.waitKey(1) & 0xFF == ord('q'):
            break

camera0 = Picamera2(0)
camera1 = Picamera2(1)

# それぞれのカメラに対して設定を行い、起動
try:
    print("Configuring camera 0")
    config0 = camera0.create_preview_configuration(main={"size": (w, h)})
    camera0.configure(config0)
    print("Starting camera 0")
    camera0.start()
    print("Camera 0 started")

    print("Configuring camera 1")
    config1 = camera1.create_preview_configuration(main={"size": (w, h)})
    camera1.configure(config1)
    print("Starting camera 1")
    camera1.start()
    print("Camera 1 started")

    # カメラストリームを表示
    show_camera_stream(camera0, camera1)

except Exception as e:
    print(f"An error occurred: {e}")

finally:
    print("Stopping cameras...")
    camera0.stop()
    camera1.stop()
    cv2.destroyAllWindows()
    print("Cameras stopped.")
