from picamera2 import Picamera2
import numpy as np
import os
import cv2


class Camera:
    def __init__(self, camera_number):

        self.camera_number = camera_number
        self.height = 480
        self.width = 640

        # 赤のHSV範囲を定義
        self.lower_red1 = np.array([0, 50, 50])   # 最初の赤の範囲（0°付近）
        self.upper_red1 = np.array([10, 255, 255])
        self.lower_red2 = np.array([170, 50, 50])  # もう一つの赤の範囲（360°付近）
        self.upper_red2 = np.array([180, 255, 255])

        # 青のHSV範囲を定義
        self.lower_blue = np.array([100, 150, 50])
        self.upper_blue = np.array([130, 255, 255])

        # 緑のHSV範囲を定義
        self.lower_green = np.array([35, 100, 110])
        self.upper_green = np.array([85, 255, 255])


        # カメラ行列と歪み係数, 回転ベクトル，平行移動ベクトルをファイルから読み取る
        camera_matrix_file = f'./camera_parameters/camera_matrix{self.camera_number}.npy'
        dist_coeffs_file = f'./camera_parameters/dist_coeffs{self.camera_number}.npy'
        rotation_vector_file = f'./camera_parameters/rotation_vector{self.camera_number}.npy'
        translation_vector_file = f'./camera_parameters/translation_vector{self.camera_number}.npy'

        # ファイルが存在するか確認
        if not os.path.exists(camera_matrix_file) or not os.path.exists(dist_coeffs_file):
            print(f"{camera_matrix_file} または {dist_coeffs_file} が見つかりませんでした。")
            exit()

        # rotation_vectorとtranslation_vectorの存在を確認
        if not os.path.exists(rotation_vector_file) or not os.path.exists(translation_vector_file):
            print(f"{rotation_vector_file} または {translation_vector_file} が見つかりませんでした。")
            exit()

        # カメラ行列と歪み係数を読み込み
        self.camera_matrix = np.load(camera_matrix_file)
        self.dist_coeffs = np.load(dist_coeffs_file)

        # 回転ベクトルと平行移動ベクトルを読み込み
        self.rotation_vector = np.load(rotation_vector_file)
        self.translation_vector = np.load(translation_vector_file)

        #カメラを準備
        self.camera = Picamera2(camera_number)
        config = self.camera.create_preview_configuration(main={"size": (self.width, self.height)})
        self.camera.configure(config)
        self.camera.start()

    def take_pic(self):
        image = self.camera.capture_array()
        image = cv2.cvtColor(image, cv2.COLOR_RGB2BGR)
        return image
    
    def show_video(self, image):
        cv2.imshow(f"camera{self.camera_number}", image)
        cv2.waitKey(1)

    def find_red_blocks(self, image):
        # HSV色空間に変換
        image_hsv = cv2.cvtColor(image, cv2.COLOR_BGR2HSV)
        # 赤色のマスクを作成
        mask1 = cv2.inRange(image_hsv, self.lower_red1, self.upper_red1)
        mask2 = cv2.inRange(image_hsv, self.lower_red2, self.upper_red2)
        mask = cv2.add(mask1, mask2)
        
        # 輪郭を見つける
        contours, _ = cv2.findContours(mask, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
        
        coords = []  # 座標を格納するリスト
        if contours:
            # 面積が大きい順に輪郭をソート
            contours = sorted(contours, key=cv2.contourArea, reverse=True)
            # 最大2つの輪郭を処理
            for contour in contours[:2]:
                area = cv2.contourArea(contour)
                if area > 200:  # ノイズを無視するための閾値
                    # モーメントを計算して重心を取得
                    M = cv2.moments(contour)
                    if M['m00'] != 0:
                        center_x = int(M['m10'] / M['m00'])
                        center_y = int(M['m01'] / M['m00'])
                        coord = [center_x, center_y]
                        coords.append(coord)
                        
                else:
                    break  # 面積が閾値以下の場合は終了
            # 2つの座標が取得できなかった場合は、-1を補完
            while len(coords) < 2:
                coords.append([-1, -1])
            return coords
        else:
            # 輪郭が見つからなかった場合、[-1, -1]を2つ返す
            return [[-1, -1], [-1, -1]]

    def find_blue_blocks(self, image):
        # HSV色空間に変換
        image_hsv = cv2.cvtColor(image, cv2.COLOR_BGR2HSV)
        # 青色のマスクを作成
        mask = cv2.inRange(image_hsv, self.lower_blue, self.upper_blue)
        
        # 輪郭を見つける
        contours, _ = cv2.findContours(mask, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
        
        coords = []  # 座標を格納するリスト
        if contours:
            # 面積が大きい順に輪郭をソート
            contours = sorted(contours, key=cv2.contourArea, reverse=True)
            # 最大2つの輪郭を処理
            for contour in contours[:2]:
                area = cv2.contourArea(contour)
                if area > 200:  # ノイズを無視するための閾値
                    # モーメントを計算して重心を取得
                    M = cv2.moments(contour)
                    if M['m00'] != 0:
                        center_x = int(M['m10'] / M['m00'])
                        center_y = int(M['m01'] / M['m00'])
                        coord = [center_x, center_y]
                        coords.append(coord)
                else:
                    break  # 面積が閾値以下の場合は終了
            # 2つの座標が取得できなかった場合は、-1を補完
            while len(coords) < 2:
                coords.append([-1, -1])
            return coords
        else:
            self.show_video(image)
            # 輪郭が見つからなかった場合、[-1, -1]を2つ返す
            return [[-1, -1], [-1, -1]]

    def find_blocks(self, image):
        red_coords = self.find_red_blocks(image)
        blue_coords = self.find_blue_blocks(image)
        coords = []

        for red_coord in red_coords:
            if (red_coord[0] != -1):
                cv2.circle(image, (red_coord[0], red_coord[1]), 5, (0, 255, 0), -1)
            coords.append(red_coord)

        for blue_coord in blue_coords:
            if (blue_coord[0] != -1):
                cv2.circle(image, (blue_coord[0], blue_coord[1]), 5, (0, 255, 0), -1)
            coords.append(blue_coord)
        
        return coords, image

    def get_straight_line(self, coord):
        image_point = np.array([coord], dtype=np.float32)

        # 歪み補正
        undistorted_point = cv2.undistortPoints(
            np.expand_dims(image_point, axis=1),
            self.camera_matrix,
            self.dist_coeffs,
            P=None
        )

        x_cam = undistorted_point[0][0][0]
        y_cam = undistorted_point[0][0][1]

        ray_camera = np.array([x_cam, y_cam, 1.0]).reshape(3, 1)

        # 回転ベクトルを回転行列に変換
        R, _ = cv2.Rodrigues(self.rotation_vector)

        # カメラ座標系のレイをワールド座標系のレイに変換
        ray_world = R.T @ ray_camera
        ray_world_unit = ray_world / np.linalg.norm(ray_world)

        # カメラの位置（ワールド座標系）
        camera_position = -R.T @ self.translation_vector

        camera_position = camera_position.flatten()

        ray_world_unit = ray_world_unit.flatten()

        return camera_position, ray_world_unit

    def get_all_lines(self, coords):
        camera_position_red0, ray_world_unit_red0 = self.get_straight_line(coords[0])
        camera_position_red1, ray_world_unit_red1 = self.get_straight_line(coords[1])
        camera_position_blue0, ray_world_unit_blue0 = self.get_straight_line(coords[2])
        camera_position_blue1, ray_world_unit_blue1 = self.get_straight_line(coords[3])
        lines_world = [
            (camera_position_red0, ray_world_unit_red0),
            (camera_position_red1, ray_world_unit_red1),
            (camera_position_blue0, ray_world_unit_blue0),
            (camera_position_blue1, ray_world_unit_blue1),
        ]
        return lines_world

    def find_endeffector(self, image):
        # HSV色空間に変換
        image_hsv = cv2.cvtColor(image, cv2.COLOR_BGR2HSV)
        # 緑色のマスクを作成
        mask = cv2.inRange(image_hsv, self.lower_green, self.upper_green)
        
        # 輪郭を見つける
        contours, _ = cv2.findContours(mask, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
        
        if contours:
            # 最大の輪郭を見つける
            largest_contour = max(contours, key=cv2.contourArea)
            area = cv2.contourArea(largest_contour)
            if area > 200:  # ノイズを無視するための閾値
                # モーメントを計算して重心を取得
                M = cv2.moments(largest_contour)
                if M['m00'] != 0:
                    center_x = int(M['m10'] / M['m00'])
                    center_y = int(M['m01'] / M['m00'])
                    coord = [center_x, center_y]
                    # 重心にマーカーを描画
                    cv2.circle(image, (center_x, center_y), 5, (0, 255, 0), -1)
                    self.show_video(image)
                    return coord
        self.show_video(image)
        return [-1, -1]  # ブロックが検出されなかった場合

    def clean_up_cam(self):
        self.camera.stop()
        self.camera.close()
        cv2.destroyAllWindows()